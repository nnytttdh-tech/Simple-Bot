const handler = async (m) => {
  const start = Date.now();
  await m.reply(`🏓 Pong!\nالاستجابة: ${Date.now() - start} ms`);
};
handler.command = ["ping", "بينج"];
export default handler;
