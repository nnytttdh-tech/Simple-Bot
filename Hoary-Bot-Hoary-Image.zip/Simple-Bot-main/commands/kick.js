import { getTarget, requireGroupAdmin } from "./admin-helpers.js";

const handler = async (m, ctx) => {
  if (!(await requireGroupAdmin(m, ctx))) return;
  const target = getTarget(m);
  if (!target) return m.reply("اذكر العضو أو رد على رسالته.\nمثال: .طرد @user");
  try {
    await ctx.conn.groupParticipantsUpdate(m.chat, [target], "remove");
    await m.reply("✅ تم طلب إزالة العضو من المجموعة.");
  } catch (e) {
    await m.reply(`❌ تعذر تنفيذ الطرد: ${e.message}`);
  }
};
handler.command = ["طرد", "kick"];
export default handler;
