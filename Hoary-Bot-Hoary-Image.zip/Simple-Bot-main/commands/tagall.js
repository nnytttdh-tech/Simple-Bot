import { requireGroupAdmin } from "./admin-helpers.js";

const handler = async (m, ctx) => {
  if (!(await requireGroupAdmin(m, ctx))) return;
  try {
    const metadata = await ctx.conn.groupMetadata(m.chat);
    const participants = metadata.participants || [];
    const mentions = participants.map(p => p.id || p.jid).filter(Boolean);
    const note = String(m.text || "").replace(/^[.!]\S+\s*/, "").trim();
    const lines = mentions.map((jid, i) => `${i + 1}. @${jid.split("@")[0]}`);
    await ctx.conn.sendMessage(m.chat, {
      text: `📢 منشن جماعي — هہ‏‏وآريـﮯ\n${note ? `الرسالة: ${note}\n` : ""}\n${lines.join("\n")}`,
      mentions
    }, { quoted: m });
  } catch (e) {
    await m.reply(`❌ تعذر عمل المنشن: ${e.message}`);
  }
};
handler.command = ["منشن", "tagall"];
export default handler;
