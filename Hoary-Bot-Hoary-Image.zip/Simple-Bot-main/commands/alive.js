const handler = async (m) => {
  const seconds = Math.floor(process.uptime());
  const h = Math.floor(seconds / 3600);
  const min = Math.floor((seconds % 3600) / 60);
  const sec = seconds % 60;
  await m.reply(`╭─「 هہ‏‏وآريـﮯ 」\n│ ✅ البوت يعمل\n│ ⏱️ مدة التشغيل: ${h}س ${min}د ${sec}ث\n╰────────────`);
};
handler.command = ["alive", "شغال", "uptime"];
export default handler;
