import { getTarget, requireGroupAdmin } from "./admin-helpers.js";

const handler = async (m, ctx) => {
  if (!(await requireGroupAdmin(m, ctx))) return;
  const target = getTarget(m);
  if (!target) return m.reply("اذكر المشرف أو رد على رسالته.\nمثال: .تنزيل @user");
  try {
    await ctx.conn.groupParticipantsUpdate(m.chat, [target], "demote");
    await m.reply("✅ تم إزالة صلاحية الإشراف.");
  } catch (e) {
    await m.reply(`❌ تعذر تنزيل المشرف: ${e.message}`);
  }
};
handler.command = ["تنزيل", "demote"];
export default handler;
