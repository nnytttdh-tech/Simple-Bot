import { requireGroupAdmin } from "./admin-helpers.js";

const handler = async (m, ctx) => {
  if (!(await requireGroupAdmin(m, ctx))) return;
  const action = String(m.text || "").trim().split(/\s+/)[0].replace(/^[.!]/, "");
  const setting = action === "قفل" ? "announcement" : "not_announcement";
  try {
    await ctx.conn.groupSettingUpdate(m.chat, setting);
    await m.reply(action === "قفل"
      ? "🔒 تم قفل المجموعة أمام الأعضاء."
      : "🔓 تم فتح المجموعة أمام الأعضاء.");
  } catch (e) {
    await m.reply(`❌ تعذر تغيير إعدادات المجموعة: ${e.message}`);
  }
};
handler.command = ["قفل", "فتح"];
export default handler;
