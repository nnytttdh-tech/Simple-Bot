export function isGroupChat(m) {
  return String(m.chat || m.key?.remoteJid || "").endsWith("@g.us");
}

export function getTarget(m) {
  const mentioned = Array.isArray(m.mentionedJid) ? m.mentionedJid[0] : null;
  const quoted = m.quoted?.sender || m.quoted?.participant || null;
  return mentioned || quoted || null;
}

export async function requireGroupAdmin(m, ctx) {
  const { isAdmin, isBotAdmin } = ctx;
  if (!isGroupChat(m)) {
    await m.reply("❌ الأمر ده للمجموعات فقط.");
    return false;
  }
  if (!isAdmin) {
    await m.reply("❌ الأمر متاح لمشرفي المجموعة فقط.");
    return false;
  }
  if (!isBotAdmin) {
    await m.reply("❌ لازم ترفع البوت مشرفًا أولاً.");
    return false;
  }
  return true;
}
