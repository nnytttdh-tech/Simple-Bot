const handler = async (m) => {
  await m.reply("✅ اختبار البوت ناجح\nالنظام يعمل ويستقبل الأوامر.");
};
handler.command = ["test", "تست"];
export default handler;
