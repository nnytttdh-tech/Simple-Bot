import { isGroupChat } from "./admin-helpers.js";

const handler = async (m, { conn }) => {
  if (!isGroupChat(m)) return m.reply("❌ الأمر ده للمجموعات فقط.");
  try {
    const g = await conn.groupMetadata(m.chat);
    const admins = (g.participants || []).filter(p => p.admin).length;
    await m.reply(
      `╭─「 معلومات المجموعة 」\n` +
      `│ الاسم: ${g.subject || "غير متاح"}\n` +
      `│ الأعضاء: ${(g.participants || []).length}\n` +
      `│ المشرفون: ${admins}\n` +
      `│ الوصف: ${g.desc || "لا يوجد"}\n` +
      `╰─ هہ‏‏وآريـﮯ`
    );
  } catch (e) {
    await m.reply(`❌ تعذر جلب المعلومات: ${e.message}`);
  }
};
handler.command = ["معلومات", "groupinfo"];
export default handler;
