import { getTarget, requireGroupAdmin } from "./admin-helpers.js";

const handler = async (m, ctx) => {
  if (!(await requireGroupAdmin(m, ctx))) return;
  const target = getTarget(m);
  if (!target) return m.reply("اذكر العضو أو رد على رسالته.\nمثال: .رفع @user");
  try {
    await ctx.conn.groupParticipantsUpdate(m.chat, [target], "promote");
    await m.reply("✅ تم ترقية العضو إلى مشرف.");
  } catch (e) {
    await m.reply(`❌ تعذرت الترقية: ${e.message}`);
  }
};
handler.command = ["رفع", "promote"];
export default handler;
