const handler = async (m, { conn, cli }) => {
  let commands = [];

  try {
    const loaded = await cli.commands();
    for (const item of loaded || []) {
      const names = Array.isArray(item.command) ? item.command : [];
      for (const name of names) {
        if (name && !commands.includes(name)) commands.push(name);
      }
    }
  } catch (error) {
    console.error("Menu command listing failed:", error);
  }

  commands.sort((a, b) => String(a).localeCompare(String(b), "ar"));

  const examples = commands.filter(name => String(name).startsWith("مثال"));
  const admin = [
    "طرد", "رفع", "تنزيل", "قفل", "فتح", "منشن", "معلومات"
  ];
  const tests = ["ping", "test", "alive", "uptime", "info"];

  const section = (title, items) =>
    items.length ? `\n\n╭─「 ${title} 」\n${items.map(x => `│ • .${x}`).join("\n")}\n╰────────────` : "";

  const known = new Set([...examples, ...admin, ...tests]);
  const other = commands.filter(name => !known.has(name));

  const text =
`╭━━━〔 هہ‏‏وآريـﮯ 〕━━━╮
│ أهلاً بك في قائمة أوامر البوت
│ المطور: هہ‏‏وآريـﮯ
╰━━━━━━━━━━━━━━━━━━╯` +
    section("أوامر الاختبار", tests) +
    section("أوامر الإدارة", admin) +
    section("أوامر Example", examples) +
    section("باقي الأوامر", other) +
`\n\nاستخدم النقطة أو علامة التعجب قبل الأمر.
مثال: .ping`;

  return conn.sendMessage(m.chat, { text }, { quoted: m });
};

handler.command = ["menu", "القائمة", "اوامر"];
export default handler;
