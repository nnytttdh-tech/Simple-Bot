const handler = async (m, { conn }) => {

 return await conn.docThumb(m.chat, {
  image: 'https://ibb.co/5XYVrQHv',
  size: 1024000,
  fileName: 'هہ‏‏وآريـﮯ'
}, m)


};

handler.command = ['مثال9'];
export default handler;