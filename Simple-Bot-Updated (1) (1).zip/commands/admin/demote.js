import { getTargets } from "../../system/utils.js";

const handler = async (m, { conn, text }) => {
  const targets = getTargets(m, text);
  if (!targets.length) return m.reply("❌ منشن الشخص أو رد على رسالته.");
  await conn.groupParticipantsUpdate(m.chat, targets, "demote");
  await m.reply("✅ تم تنزيله من الادمن");
};
handler.command = ["تنزيل", "خفض"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
