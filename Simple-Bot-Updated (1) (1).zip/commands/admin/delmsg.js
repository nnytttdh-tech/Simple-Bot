const handler = async (m, { conn }) => {
  const q = m.quoted;
  if (!q) return m.reply("❌ رد على الرسالة اللي عايز تمسحها.");
  const key = q.key || {
    remoteJid: m.chat,
    fromMe: !!q.fromMe,
    id: q.id,
    participant: q.sender || q.participant,
  };
  await conn.sendMessage(m.chat, { delete: key });
};
handler.command = ["مسح", "حذف_رسالة"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
