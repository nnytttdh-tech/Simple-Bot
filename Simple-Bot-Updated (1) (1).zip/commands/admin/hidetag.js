const handler = async (m, { conn, text }) => {
  const meta = await conn.groupMetadata(m.chat);
  const ids = meta.participants.map((p) => p.id || p.jid);
  await conn.sendMessage(m.chat, { text: text || "📢", mentions: ids });
};
handler.command = ["اخفاء", "هايد"];
handler.group = true;
handler.admin = true;
export default handler;
