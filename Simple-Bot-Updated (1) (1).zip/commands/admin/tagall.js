import { num } from "../../system/utils.js";

const handler = async (m, { conn, text }) => {
  const meta = await conn.groupMetadata(m.chat);
  const ids = meta.participants.map((p) => p.id || p.jid);
  const list = ids.map((j) => `◈ @${num(j)}`).join("\n");
  await conn.sendMessage(
    m.chat,
    { text: `📢 ${text || "منشن للجميع"}\n\n${list}`, mentions: ids },
    { quoted: m }
  );
};
handler.command = ["منشن", "تاج"];
handler.group = true;
handler.admin = true;
export default handler;
