import { getTargets } from "../../system/utils.js";

const handler = async (m, { conn, text }) => {
  const targets = getTargets(m, text);
  if (!targets.length) return m.reply("❌ منشن الشخص أو رد على رسالته.\nمثال: !طرد @الشخص");
  await conn.groupParticipantsUpdate(m.chat, targets, "remove");
  await m.reply(`✅ تم طرد ${targets.length} عضو`);
};
handler.command = ["طرد", "كيك"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
