import { IMG, SECTIONS } from "../system/menuData.js";

const handler = async (m, { conn }) => {
  const rows = Object.entries(SECTIONS).map(([id, s]) => ({
    header: "قسم",
    title: s.title,
    description: "اضغط لعرض الأوامر",
    id: `.${id}`,
  }));

  try {
    return await conn.buttonV2(
      m.chat,
      {
        text: "اختار القسم اللي عايزه 👇",
        footer: "قائمة الأوامر",
        image: IMG,
        buttons: [
          ...Object.entries(SECTIONS).slice(0, 3).map(([id, s]) => ({
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({ display_text: s.title, id: `.${id}` }),
          })),
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "كل الأقسام",
              sections: [{ title: "الأقسام", rows }],
            }),
          },
        ],
      },
      { quoted: m }
    );
  } catch {
    // لو الأزرار مشتغلتش نبعت قائمة نصية
    const txt = Object.values(SECTIONS).map((s) => `*${s.title}*\n${s.text}`).join("\n\n");
    await conn.sendMessage(m.chat, { text: txt }, { quoted: m });
  }
};
handler.command = ["اوامر", "قائمة", "الاوامر"];
export default handler;
