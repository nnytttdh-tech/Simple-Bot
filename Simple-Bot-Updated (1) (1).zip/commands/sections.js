import { IMG, SECTIONS } from "../system/menuData.js";

const handler = async (m, { conn }) => {
  const used = (m.text || "").trim().replace(/^[.!]/, "").split(/\s+/)[0];
  const s = SECTIONS[used];
  if (!s) return;

  try {
    return await conn.buttonV1(m.chat, {
      text: `*${s.title}*\n\n${s.text}`,
      footer: "اضغط رجوع للقائمة",
      buttons: [{ displayText: "🔙 رجوع", id: ".اوامر" }],
      image: IMG,
    });
  } catch {
    await conn.sendMessage(m.chat, { text: `*${s.title}*\n\n${s.text}` }, { quoted: m });
  }
};
handler.command = Object.keys(SECTIONS);
export default handler;
