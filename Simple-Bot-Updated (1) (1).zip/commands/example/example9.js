const handler = async (m, { conn }) => {

 return await conn.docThumb(m.chat, {
  image: 'https://i.ibb.co/ymhJ6zj5/48f0293afb53426617e8f06c2a36b473.jpg',
  size: 1024000,
  fileName: 'M ari/N 🎀'
}, m)


};

handler.command = ['مثال9'];
export default handler;