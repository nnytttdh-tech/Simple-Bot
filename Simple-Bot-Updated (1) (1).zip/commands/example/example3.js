const handler = async (m, { conn }) => {

  return await conn.buttonV3(m.chat, {
    image: 'https://i.ibb.co/ymhJ6zj5/48f0293afb53426617e8f06c2a36b473.jpg',
    text: 'Choose a format',
    buttons: [
      {
        name: "quick_reply",
        params: {
          display_text: "A",
          id: ". "
        }
      }, 
      {
        name: "quick_reply",
        params: {
          display_text: "B",
          id: ". "
        }
      },
      {
        name: "quick_reply",
        params: {
          display_text: "C",
          id: ". "
        }
      }
    ],
    newsletter: {
      jid: '120363409527479223@newsletter',
      name: 'Channel VA 🎶'
    }
  }, m);
  
};

handler.command = ['مثال3'];

export default handler;