const handler = async (m, { conn }) => {

 return await conn.buttonV1(m.chat, {
    text: "Hello this is a button message",
    footer: "Click the button below",
    buttons: [
        { displayText: "Click Me", id: "=> ..." },
        { displayText: "Cancel", id: "=> ..." }
    ],
    image: "https://i.ibb.co/ymhJ6zj5/48f0293afb53426617e8f06c2a36b473.jpg"
 });


};

handler.command = ['مثال1'];
export default handler;