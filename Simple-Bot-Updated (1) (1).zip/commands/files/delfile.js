import fs from "node:fs";
import path from "node:path";
import { COMMANDS_DIR, PROTECTED, safeName, findFile } from "../../system/files.js";

const handler = async (m, { text }) => {
  const file = safeName(text);
  if (!file) return m.reply("❌ اكتب اسم الملف.\nمثال: !حذف_ملف اسم");
  if (PROTECTED.includes(file)) return m.reply("⛔ الملف ده محمي ومينفعش يتحذف.");

  const target = findFile(file);
  if (!target) return m.reply(`❌ مفيش ملف باسم ${file}`);

  fs.rmSync(target);
  await m.reply(
    `🗑️ تم حذف: commands/${path.relative(COMMANDS_DIR, target)}\n\n🔄 اكتب !اعادة_تشغيل عشان يتطبق.`
  );
};
handler.command = ["حذف_ملف"];
handler.owner = true;
export default handler;
