import path from "node:path";
import { COMMANDS_DIR, walk } from "../../system/files.js";

const handler = async (m) => {
  const list = walk().map((p) => `◈ ${path.relative(COMMANDS_DIR, p)}`);
  await m.reply(`📂 *ملفات الأوامر (${list.length})*\n\n${list.join("\n")}`);
};
handler.command = ["الملفات"];
handler.owner = true;
export default handler;
