import fs from "node:fs";
import path from "node:path";
import { COMMANDS_DIR, PROTECTED, safeName, findFile, checkSyntax } from "../../system/files.js";

const handler = async (m, { text }) => {
  const parts = (text || "").trim().split(/\s+/);
  const file = safeName(parts[0]);
  if (!file) {
    return m.reply(
      "❌ اكتب اسم الملف.\n\n" +
      "الطرق:\n" +
      "1) رد على ملف .js وكتب: !اضافه_ملف اسم\n" +
      "2) رد على رسالة فيها الكود\n" +
      "3) !اضافه_ملف اسم ثم الكود في نفس الرسالة"
    );
  }
  if (PROTECTED.includes(file)) return m.reply("⛔ الملف ده محمي.");

  let code = "";
  const q = m.quoted;

  // 1) ملف مرفق في الرد
  if (q) {
    try {
      const buf = await q.download?.();
      if (buf && buf.length) code = buf.toString("utf8");
    } catch {}
    // 2) نص الرسالة المردود عليها
    if (!code) code = q.text || q.body || "";
  }
  // 3) الكود بعد الاسم
  if (!code) code = (text || "").trim().slice(parts[0].length).trim();

  code = code.replace(/^```(?:js|javascript)?\n?/i, "").replace(/```$/, "").trim();
  if (!code) return m.reply("❌ مفيش كود. ابعت ملف أو الكود نفسه.");

  const err = await checkSyntax(code);
  if (err) return m.reply(`❌ في خطأ في الكود ومتحفظش:\n\n${err}`);

  const existing = findFile(file);
  const target = existing || path.join(COMMANDS_DIR, file);
  fs.writeFileSync(target, code);

  await m.reply(
    `✅ ${existing ? "تم استبدال" : "تم حفظ"} الملف: ${file}\n` +
    `📁 commands/${path.relative(COMMANDS_DIR, target)}\n\n` +
    `🔄 اكتب !اعادة_تشغيل عشان يشتغل.`
  );
};
handler.command = ["اضافه_ملف", "اضافة_ملف"];
handler.owner = true;
export default handler;
