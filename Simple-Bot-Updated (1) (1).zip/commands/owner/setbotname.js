const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ اكتب الاسم الجديد.");
  await conn.updateProfileName(text);
  await m.reply("✅ تم تغيير اسم البوت");
};
handler.command = ["اسم_البوت"];
handler.owner = true;
export default handler;
