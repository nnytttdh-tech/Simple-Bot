const handler = async (m) => {
  const up = process.uptime();
  const h = Math.floor(up / 3600), mi = Math.floor((up % 3600) / 60), s = Math.floor(up % 60);
  const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
  await m.reply(
    `🤖 *حالة البوت*\n\n◈ التشغيل: ${h}س ${mi}د ${s}ث\n◈ الرام: ${mem} MB\n◈ Node: ${process.version}`
  );
};
handler.command = ["حالة", "بينج"];
handler.owner = true;
export default handler;
