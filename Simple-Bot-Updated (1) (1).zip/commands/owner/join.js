const handler = async (m, { conn, text }) => {
  const code = text?.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)?.[1];
  if (!code) return m.reply("❌ ابعت رابط مجموعة صحيح.");
  await conn.groupAcceptInvite(code);
  await m.reply("✅ تم الانضمام");
};
handler.command = ["انضم"];
handler.owner = true;
export default handler;
