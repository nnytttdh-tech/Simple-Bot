import { getTargets } from "../../system/utils.js";

const handler = async (m, { conn, text }) => {
  const t = getTargets(m, text);
  const target = t[0] || (!m.chat.endsWith("@g.us") ? m.chat : null);
  if (!target) return m.reply("❌ منشن الشخص أو اكتب رقمه.");
  await conn.updateBlockStatus(target, "block");
  await m.reply("🚫 تم الحظر");
};
handler.command = ["حظر"];
handler.owner = true;
export default handler;
