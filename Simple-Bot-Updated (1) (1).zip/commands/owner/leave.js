const handler = async (m, { conn, text }) => {
  const id = text?.trim() || (m.chat.endsWith("@g.us") ? m.chat : null);
  if (!id) return m.reply("❌ اكتب id المجموعة أو استخدم الأمر جوا المجموعة.");
  await conn.groupLeave(id);
};
handler.command = ["مغادرة"];
handler.owner = true;
export default handler;
