import { Misc } from "meowsab";

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ اكتب الرسالة.\nمثال: !بث السلام عليكم");
  const groups = Object.keys(await conn.groupFetchAllParticipating());
  await m.reply(`📡 جاري الإرسال لـ ${groups.length} مجموعة...`);
  let ok = 0;
  for (const id of groups) {
    try {
      await conn.sendMessage(id, { text: `📢 *إعلان من المطور*\n\n${text}` });
      ok++;
    } catch {}
    await Misc.delay(1500); // تأخير عشان الحظر
  }
  await m.reply(`✅ تم الإرسال لـ ${ok}/${groups.length}`);
};
handler.command = ["بث"];
handler.owner = true;
export default handler;
