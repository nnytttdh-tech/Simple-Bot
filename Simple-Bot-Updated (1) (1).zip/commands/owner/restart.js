const handler = async (m) => {
  await m.reply("🔄 جاري إعادة التشغيل...");
  // exit code 1 عشان Railway (ON_FAILURE) يشغله تاني
  setTimeout(() => process.exit(1), 1500);
};
handler.command = ["اعادة_تشغيل", "ريستارت"];
handler.owner = true;
export default handler;
