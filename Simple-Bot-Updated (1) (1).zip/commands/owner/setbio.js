const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ اكتب البايو الجديد.");
  await conn.updateProfileStatus(text);
  await m.reply("✅ تم تغيير البايو");
};
handler.command = ["بايو_البوت"];
handler.owner = true;
export default handler;
