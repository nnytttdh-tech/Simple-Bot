const handler = async (m, { conn }) => {
  const all = Object.values(await conn.groupFetchAllParticipating());
  const list = all.map((g, i) => `${i + 1}. ${g.subject} (${g.participants.length})\n   ${g.id}`);
  await m.reply(`📋 *المجموعات (${all.length})*\n\n${list.join("\n")}`);
};
handler.command = ["المجموعات"];
handler.owner = true;
export default handler;
