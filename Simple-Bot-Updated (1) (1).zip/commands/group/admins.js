import { num } from "../../system/utils.js";

const handler = async (m, { conn }) => {
  const meta = await conn.groupMetadata(m.chat);
  const admins = meta.participants.filter((p) => p.admin).map((p) => p.id || p.jid);
  const list = admins.map((j) => `◈ @${num(j)}`).join("\n");
  await conn.sendMessage(
    m.chat,
    { text: `👑 *ادمنز المجموعة*\n\n${list}`, mentions: admins },
    { quoted: m }
  );
};
handler.command = ["الادمنز", "المشرفين"];
handler.group = true;
export default handler;
