const handler = async (m, { conn }) => {
  await conn.groupSettingUpdate(m.chat, "not_announcement");
  await m.reply("🔓 تم فتح المجموعة، الكل يقدر يكتب");
};
handler.command = ["فتح"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
