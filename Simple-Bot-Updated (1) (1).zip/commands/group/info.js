import { IMG } from "../../system/menuData.js";

const handler = async (m, { conn }) => {
  const meta = await conn.groupMetadata(m.chat);
  const admins = meta.participants.filter((p) => p.admin);
  const text =
    `📋 *معلومات المجموعة*\n\n` +
    `◈ الاسم: ${meta.subject}\n` +
    `◈ الأعضاء: ${meta.participants.length}\n` +
    `◈ الادمنز: ${admins.length}\n` +
    `◈ الوصف: ${meta.desc || "لا يوجد"}`;

  try {
    return await conn.buttonV1(m.chat, {
      text,
      footer: "تحكم سريع (للادمن)",
      buttons: [
        { displayText: "🔓 فتح", id: ".فتح" },
        { displayText: "🔒 قفل", id: ".قفل" },
        { displayText: "🔗 الرابط", id: ".رابط" },
      ],
      image: IMG,
    });
  } catch {
    await m.reply(text);
  }
};
handler.command = ["معلومات", "المجموعة"];
handler.group = true;
export default handler;
