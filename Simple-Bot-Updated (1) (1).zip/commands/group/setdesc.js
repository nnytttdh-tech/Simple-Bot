const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ اكتب الوصف الجديد.");
  await conn.groupUpdateDescription(m.chat, text);
  await m.reply("✅ تم تغيير وصف المجموعة");
};
handler.command = ["وصف_المجموعة"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
