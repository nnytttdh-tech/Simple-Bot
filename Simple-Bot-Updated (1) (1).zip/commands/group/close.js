const handler = async (m, { conn }) => {
  await conn.groupSettingUpdate(m.chat, "announcement");
  await m.reply("🔒 تم قفل المجموعة، الادمن بس يكتب");
};
handler.command = ["قفل"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
