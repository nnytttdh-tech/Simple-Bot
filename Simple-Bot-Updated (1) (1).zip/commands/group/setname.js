const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("❌ اكتب الاسم الجديد.\nمثال: !اسم_المجموعة اسم جديد");
  await conn.groupUpdateSubject(m.chat, text);
  await m.reply("✅ تم تغيير اسم المجموعة");
};
handler.command = ["اسم_المجموعة"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
