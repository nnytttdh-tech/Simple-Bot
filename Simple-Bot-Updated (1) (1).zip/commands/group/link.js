const handler = async (m, { conn }) => {
  const code = await conn.groupInviteCode(m.chat);
  await m.reply(`🔗 رابط المجموعة:\nhttps://chat.whatsapp.com/${code}`);
};
handler.command = ["رابط"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
