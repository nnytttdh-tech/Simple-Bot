const handler = async (m, { conn }) => {
  const code = await conn.groupRevokeInvite(m.chat);
  await m.reply(`♻️ تم تغيير الرابط:\nhttps://chat.whatsapp.com/${code}`);
};
handler.command = ["تغيير_الرابط"];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
export default handler;
