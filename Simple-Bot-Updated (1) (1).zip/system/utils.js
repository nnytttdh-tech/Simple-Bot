// دوال مساعدة مشتركة بين الأوامر (برا فولدر commands عشان متتحملش كأمر)
export const num = (jid = "") => String(jid).split("@")[0].split(":")[0];

export function getTargets(m, text = "") {
  const out = new Set();
  const mentioned =
    m.mentionedJid ||
    m.mentions ||
    m.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    [];
  for (const j of mentioned) out.add(j);

  const q = m.quoted?.sender || m.quoted?.jid || m.quoted?.participant;
  if (q) out.add(q);

  for (const d of (text.match(/\d{8,15}/g) || [])) out.add(`${d}@s.whatsapp.net`);
  return [...out];
}

export const sender = (m) => m.sender || m.jid || m.key?.participant;
