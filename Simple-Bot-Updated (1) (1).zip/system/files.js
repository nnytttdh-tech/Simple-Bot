import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";

export const COMMANDS_DIR = path.resolve(process.cwd(), "commands");

// ملفات محمية متتحذفش ولا تتستبدل
export const PROTECTED = ["sub.js", "eval.js", "addfile.js", "delfile.js", "listfiles.js"];

export const safeName = (raw = "") => {
  const n = raw.trim().replace(/\.js$/i, "");
  if (!n || !/^[\w\u0600-\u06FF\-]+$/.test(n)) return null; // بدون / أو ..
  return `${n}.js`;
};

export function walk(dir = COMMANDS_DIR) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p));
    else if (e.name.endsWith(".js")) out.push(p);
  }
  return out;
}

export const findFile = (file) => walk().find((p) => path.basename(p) === file);

// فحص السينتاكس قبل الحفظ عشان ملف بايظ ميوقعش البوت
export function checkSyntax(code) {
  return new Promise((resolve) => {
    const tmp = path.join(os.tmpdir(), `chk_${Date.now()}.mjs`);
    fs.writeFileSync(tmp, code);
    execFile(process.execPath, ["--check", tmp], (err, _o, stderr) => {
      fs.rmSync(tmp, { force: true });
      resolve(err ? String(stderr || err.message).split("\n").slice(0, 6).join("\n") : null);
    });
  });
}
